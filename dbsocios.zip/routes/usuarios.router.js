const express=require('express');
const { faker } = require('@faker-js/faker');

const router=express.Router();
router.get('/',(req,res)=>{
  const usuarios=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      usuarios.push(
        {
          usuario_id: faker.datatype.uuid(), // ID único para cada usuario
          email: faker.internet.email(), // Email del usuario
          password: faker.internet.password(), // Contraseña del usuario
          creado_en: faker.date.past(), // Fecha de creación
          actualizado_en: faker.date.recent(), // Fecha de actualización
        });
    }
res.json(usuarios);
});


module.exports=router;

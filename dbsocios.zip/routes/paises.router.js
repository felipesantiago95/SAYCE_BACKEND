const express=require('express');
const { faker } = require('@faker-js/faker');


const router=express.Router();
router.get('/',(req,res)=>{
  const paises=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      paises.push(
        {
          pais_id: faker.datatype.uuid(),
          nombre:faker.address.country(),
        });
    }
res.json(paises);
});


module.exports=router;


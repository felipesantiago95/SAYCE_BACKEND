const express=require('express');
const { faker } = require('@faker-js/faker');

// Lista relaciones familiares
const relacionesFamiliares = ["mamá", "papá", "primo", "hermano", "hermana", "tío", "tía", "abuelo", "abuela", "sobrino", "sobrina"];

const router=express.Router();
router.get('/',(req,res)=>{
  const apoderados=[];
  const{size}=req.query;
  const limit=size||10;
  for(let index=0;index<limit;index++)
    {
      apoderados.push(
        {
        apoderado_id: faker.datatype.uuid(), // ID único para cada apoderado
        socio_id: faker.datatype.uuid(), // ID único para cada socio
        nombre: faker.name.firstName(), // Nombre ficticio
        apellido: faker.name.lastName(), // Apellido ficticio
        cedula: faker.datatype.number({ min: 10000000, max: 99999999 }), // Cédula ficticia
        relacion: faker.helpers.arrayElement(relacionesFamiliares), // Relación familiar aleatoria
        });
    }
res.json(apoderados);
});

  // Ruta para obtener un apoderado en especifico por ID
  router.get('/:id', (req, res) => {
    const { id } = req.params;
    res.json({
      apoderado_id: id,
      socio_id: faker.datatype.uuid(), // ID único para cada socio
        nombre: faker.name.firstName(), // Nombre ficticio
        apellido: faker.name.lastName(), // Apellido ficticio
        cedula: faker.datatype.number({ min: 10000000, max: 99999999 }), // Cédula ficticia
        relacion: faker.helpers.arrayElement(relacionesFamiliares), // Relación familiar aleatoria
    });
  });

module.exports=router;


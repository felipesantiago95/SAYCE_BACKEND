const express=require('express');
const { faker } = require('@faker-js/faker');


const router=express.Router();
router.get('/',(req,res)=>{
  const detalles_seguros=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      detalles_seguros.push(
        {
          detalle_id: faker.datatype.uuid(), // ID único para cada detalle de seguro
          socio_id: faker.datatype.uuid(), // ID único para cada socio
          seguro_id: faker.datatype.uuid(), // ID único para cada seguro
          detalle: faker.lorem.sentence(), // Detalle del seguro
        });
    }
res.json(detalles_seguros);
});


module.exports=router;

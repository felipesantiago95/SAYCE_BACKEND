const express=require('express');
const { faker, Faker } = require('@faker-js/faker');

// Lista de tipos de seguros posibles
const tiposSeguros = ["Salud", "Dental"];

const router=express.Router();
router.get('/',(req,res)=>{
  const socios=[];
  const{size}=req.query;
  const limit=size||25;
  for(let index=0;index<limit;index++)
    {
      const nombre = faker.name.firstName();
      const apellido= faker.name.lastName();
      socios.push(
        {
        socio_id: faker.datatype.uuid(), // ID único para cada socio
        ip_provisional: faker.internet.ip(), // IP provisional
        codigo_provisional: faker.datatype.uuid(), // Código provisional
        codigo_socio: faker.datatype.uuid(), // Código de socio
        ip_definitivo: faker.internet.ip(), // IP definitivo
        cedula: faker.datatype.number({ min: 10000000, max: 99999999 }).toString(), // Cédula
        apellidos: apellido, // Apellidos
        nombres: nombre, // Nombres
        nombres_completos: `${nombre} ${apellido}`, // Nombres completos
        seudonimo_banda: faker.music.genre(), // Seudónimo o banda
        observacion: faker.lorem.sentence(), // Observación
        bono: faker.datatype.float({ min: 0, max: 10000, precision: 0.01 }), // Bono
        seguros_valor: faker.datatype.float({ min: 0, max: 100000, precision: 0.01 }), // Valor de seguros
        seguros_categoria: faker.commerce.department(), // Categoría de seguros
        ciudad_id: faker.datatype.uuid(), // ID de ciudad
        });
    }
res.json(socios);
});


module.exports=router;

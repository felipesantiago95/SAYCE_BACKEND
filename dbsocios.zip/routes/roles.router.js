const express=require('express');
const { faker } = require('@faker-js/faker');

// Lista de nombres de roles posibles
const nombresRoles = ["Administrador", "Usuario", "Moderador", "Invitado", "Superusuario"];

const router=express.Router();
router.get('/',(req,res)=>{
  const herederos=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      herederos.push(
        {
          rol_id: faker.datatype.uuid(), // ID único para cada rol
          nombre: faker.helpers.arrayElement(nombresRoles), // Nombre del rol
        });
    }
res.json(herederos);
});


module.exports=router;

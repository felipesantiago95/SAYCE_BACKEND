const express=require('express');
const { faker } = require('@faker-js/faker');


const router=express.Router();
router.get('/',(req,res)=>{
  const provincias=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      provincias.push(
        {
          provincia_id: faker.datatype.uuid(),
          nombre:faker.address.state(),
          pais_id: faker.datatype.uuid(),
        });
    }
res.json(provincias);
});


module.exports=router;


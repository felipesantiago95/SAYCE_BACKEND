const express=require('express');
const { faker } = require('@faker-js/faker');

// Lista de parentescos posibles
const parentescos = ["mamá", "prima", "amiga", "sobrina", "abuelita", "hijo", "hija"];

const router=express.Router();
router.get('/',(req,res)=>{
  const herederos=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      herederos.push(
        {
          heredero_id: faker.datatype.uuid(), // ID único para cada heredero
          socio_id: faker.datatype.uuid(), // ID único para cada socio
          nombre: faker.name.firstName(), // Nombre del heredero
          apellido: faker.name.lastName(), // Apellido del heredero
          cedula: faker.datatype.number({ min: 10000000, max: 99999999 }).toString(), // Cédula del heredero
          parentesco: faker.helpers.arrayElement(parentescos), // Parentesco aleatorio
        });
    }
res.json(herederos);
});


module.exports=router;

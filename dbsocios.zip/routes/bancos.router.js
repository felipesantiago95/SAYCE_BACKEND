const express=require('express');
const { faker } = require('@faker-js/faker');


const router=express.Router();
router.get('/',(req,res)=>{
  const bancos=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      bancos.push(
        {
          banco_id: faker.datatype.uuid(), // ID único para cada banco
          nombre: faker.company.name(), // Nombre del banco
        });
    }
res.json(bancos);
});


module.exports=router;


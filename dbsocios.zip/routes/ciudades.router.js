const express=require('express');
const CiudadesService = require('./../services/ciudades.service');


const router=express.Router();
const service = new CiudadesService();

router.get('/',async (req,res)=>{
  const ciudades = await service.find();
res.json(ciudades);
});

  // Ruta para obtener una ciudad específica por ID
router.get('/:ciudad_id', async (req, res) => {
  const { ciudad_id } = req.params;
  const ciudades = await service.findOne(ciudad_id);
  res.json(ciudades);
});

router.post('/', async (req, res) => {
  const body = req.body;
  const newCiudad = await service.create(body);
  res.status(201).json(newCiudad);
  });

router.patch('/:ciudad_id',async (req, res) => {
  try {
    const {ciudad_id} = req.params;
    const body = req.body;
    const ciudad = await service.update(ciudad_id, body);
    res.json(ciudad);
  } catch (error) {
    res.status(404).json({
      message: error.message
    });
  }

});

router.delete('/:ciudad_id', async (req,res)=>{
  const{ciudad_id}=req.params;
  const rta=await service.delete(ciudad_id);
  res.json(rta);
});

module.exports=router;








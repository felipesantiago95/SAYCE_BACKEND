const express=require('express');
const { faker } = require('@faker-js/faker');

// Datos FAKE
const usuariosIDs = [
  faker.datatype.uuid(), faker.datatype.uuid(), faker.datatype.uuid(),
  faker.datatype.uuid(), faker.datatype.uuid()
];

const rolesIDs = [
  faker.datatype.uuid(), faker.datatype.uuid(), faker.datatype.uuid(),
  faker.datatype.uuid(), faker.datatype.uuid()
];


const router=express.Router();
router.get('/',(req,res)=>{
  const usuario_roles=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      usuario_roles.push(
        {
          usuario_id: faker.helpers.arrayElement(usuariosIDs), // ID de usuario
          rol_id: faker.helpers.arrayElement(rolesIDs), // ID de rol
        });
    }
res.json(usuario_roles);
});


module.exports=router;

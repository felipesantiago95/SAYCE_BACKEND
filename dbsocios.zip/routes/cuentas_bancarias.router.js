const express=require('express');
const { faker } = require('@faker-js/faker');


const router=express.Router();
router.get('/',(req,res)=>{
  const cuentas_bancarias=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      cuentas_bancarias.push(
        {
        cuenta_bancaria_id: faker.datatype.uuid(), // ID único para cada cuenta bancaria
        socio_id: faker.datatype.uuid(), // ID único para cada socio
        banco_id: faker.datatype.uuid(), // ID único para cada banco
        tipo_cuenta_id: faker.datatype.uuid(), // ID único para cada tipo de cuenta
        numero_cuenta: faker.finance.account(), // Número de cuenta bancaria
        });
    }
res.json(cuentas_bancarias);
});


module.exports=router;


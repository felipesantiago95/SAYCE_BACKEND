const express=require('express');
const { faker } = require('@faker-js/faker');

// Lista de tipos de seguros posibles
const tiposSeguros = ["Salud", "Dental"];

const router=express.Router();
router.get('/',(req,res)=>{
  const tipo_cuentas=[];
  const{size}=req.query;
  const limit=size||5;
  for(let index=0;index<limit;index++)
    {
      tipo_cuentas.push(
        {
          tipo_cuenta_id: faker.datatype.uuid(), // ID único para cada tipo de cuenta
          descripcion: faker.finance.accountName(), // Descripción del tipo de cuenta
        });
    }
res.json(tipo_cuentas);
});


module.exports=router;

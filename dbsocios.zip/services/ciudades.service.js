const { faker } = require('@faker-js/faker');

class CiudadesService{
  constructor(){
    this.ciudades = [];
    this.generate();
  }
  async generate(){
    const limit=10;
    for(let index=0;index<limit;index++)
      {
        this.ciudades.push(
          {
            ciudad_id: faker.datatype.uuid(),
            nombre:faker.address.city(),
            provincia_id: faker.datatype.uuid(),
          });
      }
  }
  async create(data){
    const newCiudad = {
      ciudad_id: faker.datatype.uuid(),
      ...data,
    }
    this.ciudades.push(newCiudad);
    return newCiudad;
  }

  async find(){
    /*return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(this.ciudades);
      }, 5000);
    });*/
    return this.ciudades;
  }

  async findOne(ciudad_id){
    return this.ciudades.find(item => item.ciudad_id === ciudad_id);
  }

 async update(ciudad_id, changes){
    const index = this.ciudades.findIndex(item => item.ciudad_id === ciudad_id);
    if(index === -1){
      throw new Error('Ciudad not found');
    }
    const ciudad = this.ciudades[index];
    this.ciudades[index]= {
      ...ciudad,
      ...changes,
    };
    return this.ciudades[index];
  }

 async delete(ciudad_id){
    const index = this.ciudades.findIndex(item => item.ciudad_id === ciudad_id);
    if(index === -1){
      throw new Error('Ciudad not found');
  }
    this.ciudades.splice(index, 1);
    return {ciudad_id};
}
}

module.exports = CiudadesService;
